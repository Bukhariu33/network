//var nodemailer = require("nodemailer");
import nodemailer from "nodemailer";

var mail = (email, username, password, link, contract) => {
  console.log(
    email + " " + username + " " + password + " " + link + " " + contract
  );
  var smtpTransport = nodemailer.createTransport({
    host: "smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "1d549bd82b389b",
      pass: "d9f3a1789a9709",
    },
  });

  var mailOptions = {
    from: "info@eads.com",
    to: email,
    subject: "Eads - Your Authentication Code",
    generateTextFromHTML: true,
    html: `
      <h4>Please Enter following 6-digit code to login.</h4>
      <b>Email:  ${email}   and  Authentication Code"  ${password} </b>
      `,
  };

  smtpTransport.sendMail(mailOptions, function (error, response) {
    if (error) {
      console.log(error);
    } else {
      console.log(response);
    }
    smtpTransport.close();
  });
};
module.exports.mail = mail;
