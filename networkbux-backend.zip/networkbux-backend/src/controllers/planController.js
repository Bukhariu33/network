import { Plans } from "../models/plans";
import { Ads } from "../models/ads";
import R from "ramda";

const create_plan = async (req, res) => {
  const user = req.user._id;
  try {
    let plans = await Plans.findOne({ name: req.body.name, user: user });
    if (plans) return res.status(400).send("Plans already Save.");
    plans = new Plans(req.body);
    plans.user = user;
    await plans.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Plans is Created",
  });
};

const plan_list = async (req, res) => {
  try {
    const user_id = req.user._id;
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalPlans = await Plans.countDocuments({ user: user_id });
    // const totalPages = Math.ceil(totalPlans / eachPage);

    let planlist = await Plans.find({ user: user_id });
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    if (!planlist) return res.status(400).send("Plans not found");

    const response = {
      plans: planlist,
      // meta: {
      //   total: totalPlans,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};
const plans_public = async (req, res) => {
  try {
    let planslist = await Plans.find();
    if (!planslist) return res.status(400).send("Plans not found");
    const response = {
      plans: planslist,
      status: 200,
    };
    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const plan_get_by_id = async (req, res) => {
  try {
    const plan = await Plans.findOne({ _id: req.params.id });

    if (!plan) {
      return res.status(404).send("The Plans with the given id is not found.");
    }
    // return ads data with plan
    if (plan.ads && plan.ads.length > 0) {
      const adsData = await Promise.all(
        R.map(async (adId) => {
          const ad = await Ads.findOne({ _id: adId }).lean();
          return ad;
        }, plan.ads)
      );
      plan.adsData = adsData;
    }

    return res.json(plan);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const plan_update = async (req, res) => {
  try {
    const plans = await Plans.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!plans)
      return res
        .status(404)
        .send("The Plans with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "Plans is updated",
  });
};

const plan_delete = async (req, res) => {
  const plans = await Plans.findByIdAndRemove(req.params.id);
  if (!plans)
    return res.status(404).send("The plans with the given name is not found.");
  return res.json({
    message: "Plans is deleted",
  });
};
module.exports = {
  create_plan,
  plan_list,
  plans_public,
  plan_get_by_id,
  plan_update,
  plan_delete,
};
