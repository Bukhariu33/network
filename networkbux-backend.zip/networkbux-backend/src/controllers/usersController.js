import { Users } from "../models/users";
import User from "../models/user";
import { Plans } from "../models/plans";
import R from "ramda";
import { Ads } from "../models/ads";

const users = async (req, res) => {
  const user = req.user._id;
  try {
    console.log("body >>>", req.body);
    let user = new Users(req.body);
    // user.name = user;
    await user.save();
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "Record Created",
  });
};

const users_list = async (req, res) => {
  try {
    // const currentPage = parseInt(req.query.page) || 1;
    // const eachPage = 10; // You can adjust this based on your preference.

    // const totalUsers = await User.countDocuments();
    // const totalPages = Math.ceil(totalUsers / eachPage);

    let usersList = await User.find();
    // .skip((currentPage - 1) * eachPage)
    // .limit(eachPage);

    if (!usersList) return res.status(400).send("Users not found");

    const response = {
      users: usersList,
      // meta: {
      //   total: totalUsers,
      //   currentPage,
      //   eachPage,
      //   lastPage: totalPages,
      // },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const users_get = async (req, res) => {
  try {
    console.log("req.params.id", req.params.id);
    var user = await User.findOne({ _id: req.params.id });
    if (!user)
      return res
        .status(404)
        .send("The Users with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json(user);
};

const users_update = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!user)
      return res
        .status(404)
        .send("The Users with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "User is updated",
  });
};

const users_delete = async (req, res) => {
  try {
    const user = await User.findOneAndDelete({ _id: req.params.id });

    if (!user) {
      return res.status(404).send("The user with the given ID is not found.");
    }

    return res.json({
      message: "User is deleted",
    });
  } catch (error) {
    console.error("Error deleting user:", error);
    return res.status(500).send("Internal Server Error");
  }
};

const active_current_plan = async (req, res) => {
  try {
    const _id = req.params.id;
    const findUser = await User.findOne({ _id });
    if (!findUser)
      return res.status(404).send("The Users with the given id is not found.");
    if (findUser.subscription) {
      if (findUser.subscription.status === "pending") {
        return res
          .status(404)
          .send(
            "Your previous subscription is still pending. Please contact admin to activate your subscription or cancel your previous subscription."
          );
      }
      if (findUser.subscription.status === "active") {
        return res
          .status(404)
          .send(
            "Your previous subscription is still active. Please contact admin to cancel your previous subscription."
          );
      }
    }
    const user = await User.updateOne(
      { _id },
      { $set: { subscription: req.body } }
    );
    if (!user)
      return res.status(404).send("The Users with the given id is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "User subscription is updated",
  });
};

const subscribe_free_plan = async (req, res) => {
  try {
    const _id = req.params.id;
    const freePlan = await Plans.findOne({ planType: "free" });

    console.log("freePlan", freePlan);
    if (!freePlan) {
      return res.status(404).send("Free plan not found.");
    }

    const user = await User.updateOne(
      { _id },
      { $set: { subscription: { plan: freePlan._id, status: "approved" } } }
    );

    if (!user) {
      return res.status(404).send("The user with the given id is not found.");
    }
  } catch (err) {
    return res.json({ error: err.message });
  }

  return res.json({
    message: "User subscription is updated to the free plan.",
  });
};

const cancel_current_plan = async (req, res) => {
  try {
    const _id = req.params.id;
    const user = await User.updateOne(
      { _id },
      { $set: { subscription: null } }
    );
    if (!user)
      return res.status(404).send("The Users with the given id is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "User subscription is cancelled",
  });
};

const get_current_plan = async (req, res) => {
  try {
    var user = await User.findOne({ _id: req.params.id });
    if (!user)
      return res.status(404).send("The Users with the given id is not found.");
    if (!user.subscription) {
      return res.status(404).send("No subscription found");
    }
    if (user.subscription) {
      user = user.toObject();
      user["subscription"].plan = await Plans.findOne({
        _id: user.subscription.plan,
      });
      if (
        user["subscription"].plan &&
        user["subscription"].plan.ads.length > 0
      ) {
        const adsData = await Promise.all(
          R.map(async (adId) => {
            const ad = await Ads.findOne({ _id: adId }).lean();
            return ad;
          }, user["subscription"].plan.ads)
        );
        user["subscription"].plan.adsData = adsData;
      }
    }
    return res.json(user);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

// --------------- Referral -------------------

const referral = async (req, res) => {
  try {
    var user = await User.findOne({ referralCode: req.params.id });
    if (!user)
      return res
        .status(404)
        .send("The Users with the given referral code is not found.");
    if (!user.subscription) {
      return res.status(404).send("No subscription found for referred user.");
    }
    if (user.subscription) {
      user = user.toObject();
      if (user.subscription.status === "pending") {
        return res.status(404).send("Referred user subscription is pending.");
      }
      user["subscription"].plan = await Plans.findOne({
        _id: user.subscription.plan,
      });
      if (user["subscription"].plan) {
        if (user.referralCount === user["subscription"].plan.allowedReferrals) {
          return res.status(404).send("User have reached referral limit.");
        }
        if (user.referralCount < user["subscription"].plan.allowedReferrals) {
          user.withDrawalAmount =
            user.withDrawalAmount +
            (user["subscription"].plan.planPrice * 10) / 100;
          user.referralCount = user.referralCount + 1;
          await User.updateOne(
            { _id: user._id },
            {
              $set: {
                referralCount: user.referralCount,
                withDrawalAmount: user.withDrawalAmount,
              },
            }
          );
        }
      }
    }
    return res.json({
      message: "Referral added",
    });
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const referred_users = async (req, res) => {
  try {
    const currentPage = parseInt(req.query.page) || 1;
    const eachPage = 10; // You can adjust this based on your preference.

    const totalUsers = await User.countDocuments({
      referredBy: req.user.referralCode,
    });
    const totalPages = Math.ceil(totalUsers / eachPage);

    let usersList = await User.find({ referredBy: req.user.referralCode })
      .skip((currentPage - 1) * eachPage)
      .limit(eachPage);

    if (!usersList) return res.status(400).send("Users not found");

    const response = {
      users: usersList,
      meta: {
        total: totalUsers,
        currentPage,
        eachPage,
        lastPage: totalPages,
      },
      status: 200,
    };

    return res.json(response);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

const user_click = async (req, res) => {
  try {
    const _id = req.user._id;
    const user = await User.updateOne(
      { _id },
      {
        $set: {
          totalClicks: req.user.totalClicks + 1,
          withDrawalAmount:
            req.user.withDrawalAmount === null
              ? 0
              : req.user.withDrawalAmount + req.body.amount,
        },
      }
    );
    console.log("user", req.user._id);
    if (!user)
      return res.status(404).send("The Users with the given id is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "User click is updated",
  });
};

const get_stats = async (req, res) => {
  try {
    const _id = req.user._id;
    var user = await User.findOne({ _id });
    let plan = null;
    if (!user)
      return res.status(404).send("The Users with the given id is not found.");
    if (!user.subscription) {
      return res.status(404).send("No subscription found");
    }
    if (user.subscription) {
      plan = await Plans.findOne({
        _id: user.subscription.plan,
      });
    }
    const stats = {
      totalClicks: user.totalClicks || 0,
      totalReferrals: user.referralCount || 0,
      totalBalance: user.withDrawalAmount || 0,
      activatedPlan: plan ? plan.name : "",
      activatedPlanStatus: user.subscription ? user.subscription.status : "",
      totalAds: plan ? plan.ads.length : 0,
    };
    return res.json(stats);
  } catch (err) {
    return res.json({ error: err.message });
  }
};

module.exports = {
  users,
  users_list,
  users_get,
  users_update,
  users_delete,
  active_current_plan,
  cancel_current_plan,
  get_current_plan,
  referred_users,
  referral,
  user_click,
  get_stats,
  subscribe_free_plan,
};
