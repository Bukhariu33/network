import {
  signin,
  signup,
  getuser,
  change_password,
  resetmail,
  reset_code_verify,
  reset_password,
  delete_user,
} from "./controllers/authentication";
import adController from "./controllers/adController";
import planController from "./controllers/planController";
import usersController from "./controllers/usersController";
import depositController from "./controllers/depositController";
import withdrawController from "./controllers/withdrawController";
import profileController from "./controllers/profileController";
import passport from "passport";

const passportService = require("./services/passport");

const requireAuth = passport.authenticate("jwt", { session: false });
const requireSignin = passport.authenticate("local", { session: false });

const router = (app) => {
  app.get("/", (req, res) => {
    res.send({ message: "Eads server working! its 9011" });
  });

  app.post("/signup", signup);
  app.post("/signin", signin);
  app.get("/user", getuser);
  app.post("/reset-email", resetmail);
  app.post("/reset-verify", reset_code_verify);
  app.put("/reset-password", reset_password);
  app.put("/change-password/:id", requireAuth, change_password); // change password from profile page

  //=========================== Delete User ========================================
  app.get("/delete-user/:id", delete_user);

  app.put("/profile", requireAuth, profileController.profile);
  app.get("/profile", requireAuth, profileController.profile_get);

  // ---------- Users Management
  app.post("/users", requireAuth, usersController.users);
  app.get("/users-list", requireAuth, usersController.users_list);
  app.get("/single-user/:id", requireAuth, usersController.users_get);
  app.put("/user-update/:id", requireAuth, usersController.users_update);
  app.delete("/user-delete/:id", usersController.users_delete);
  app.get("/referred-users", requireAuth, usersController.referred_users); // get referred users
  app.post("/user-click", requireAuth, usersController.user_click); // update user click
  app.get("/get-stats", requireAuth, usersController.get_stats); // get user stats

  // ---------- Ads Management
  app.post("/ad", requireAuth, adController.create_ad);
  app.get("/ads", requireAuth, adController.ad_list);
  app.get("/ads-public", adController.ads_public);
  app.get("/ad/:id", requireAuth, adController.ad_get_by_id);
  app.put("/ad/:id", requireAuth, adController.ad_update);
  app.delete("/ad/:id", requireAuth, adController.ad_delete);
  app.post("/ad_click", requireAuth, adController.ad_click);

  // ---------- Plans Management
  app.post("/plan", requireAuth, planController.create_plan);
  app.get("/plans", requireAuth, planController.plan_list);
  app.get("/plans-public", planController.plans_public);
  app.get("/plan/:id", requireAuth, planController.plan_get_by_id);
  app.put("/plan/:id", requireAuth, planController.plan_update);
  app.delete("/plan/:id", requireAuth, planController.plan_delete);

  // ---------- Subscribe
  app.put("/subscribe/:id", requireAuth, usersController.active_current_plan);
  app.put(
    "/subscribe-free-plan/:id",
    requireAuth,
    usersController.subscribe_free_plan
  );
  app.get("/current-plan/:id", requireAuth, usersController.get_current_plan);
  app.put(
    "/cancel-subscription/:id",
    requireAuth,
    usersController.cancel_current_plan
  );

  // ---------- Deposits Management
  app.post("/deposit", requireAuth, depositController.create_deposit);
  app.get("/deposits", requireAuth, depositController.deposit_list);
  app.get("/deposits-public", depositController.deposits_public);
  app.get("/deposit/:id", requireAuth, depositController.deposit_get_by_id);
  app.put("/deposit/:id", requireAuth, depositController.deposit_update);
  app.delete("/deposit/:id", requireAuth, depositController.deposit_delete);

  // ---------- Withdraws Management
  app.post("/withdraw", requireAuth, withdrawController.create_withdraw);
  app.get("/withdraws", requireAuth, withdrawController.withdraw_list);
  app.get("/withdraws-public", withdrawController.withdraws_public);
  app.get("/withdraw/:id", requireAuth, withdrawController.withdraw_get_by_id);
  app.put("/withdraw/:id", requireAuth, withdrawController.withdraw_update);
  app.delete("/withdraw/:id", requireAuth, withdrawController.withdraw_delete);

  // ---------- Referral
  app.put("/referral/:id", requireAuth, usersController.referral);
};

export default router;
