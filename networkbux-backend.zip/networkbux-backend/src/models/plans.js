// plans.js
import Joi from "joi";
import mongoose from "mongoose";

const { Schema } = mongoose;

const userSchema = new Schema({
  name: {
    type: String,
  },
  planPrice: {
    type: String,
  },
  dailyLimit: {
    type: String,
  },
  allowedReferrals: {
    type: Number,
  },
  referralBonus: {
    type: String,
  },
  validity: {
    type: String,
  },
  ads: [
    {
      type: Schema.Types.ObjectId,
      ref: "Ads",
      required: true,
    },
  ],
  adsData: [
    {
      link: {
        type: String,
      },
      amount: {
        type: String,
      },
      duration: {
        type: String,
      },
    },
  ],
  planType: {
    type: String,
    default: "paid",
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
});

const Plans = mongoose.model("plans", userSchema);

function validatePlans(plans) {
  const schema = Joi.object({
    name: Joi.string().required(),
  });

  return Joi.validate(plans, schema);
}

export { Plans, validatePlans };
