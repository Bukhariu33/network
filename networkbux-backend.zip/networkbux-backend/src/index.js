"use strict";
require("express-async-errors");
import express from "express";
// import http from 'http';
import bodyParser from "body-parser";
import morgan from "morgan";
import mongoose from "mongoose";
import cors from "cors";
import compression from "compression";
import moment from "moment";
import router from "./router";

const app = express();

mongoose
  .connect(
    "mongodb://localhost:27017/eads",
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  )
  .then(() => console.log("Connected to MongoDB..."))
  .catch((err) => console.error("Could not connect to MongoDB..."));
// App setup
app.use(compression());
app.use(morgan("combined"));
app.use(cors());
// app.use(bodyParser.json({ type: '*/*' }));
var path = require("path");
var dir = path.join("./uploads/");
console.log(dir);
app.use(express.static(dir));
app.use(express.json());
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));
const port = process.env.PORT || 9011;
const http = require("http").Server(app);
http.listen(port);
const io = require("socket.io")(http);
app.use(function (req, res, next) {
  res.io = io;
  next();
});
router(app);

console.log(moment().format("hh:mm A"));

console.log("server listening on:", port);
