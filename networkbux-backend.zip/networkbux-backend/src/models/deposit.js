// plans.js
import Joi from "joi";
import mongoose from "mongoose";
import { subscriptionSchema } from "./user";

const { Schema } = mongoose;
const userData = new Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
  },
  subscription: subscriptionSchema,
});
const userSchema = new Schema({
  gateway: {
    type: String,
  },
  amount: {
    type: String,
  },
  transactionId: {
    type: String,
  },
  status: {
    type: String,
    default: "pending",
  },
  user: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  userData: userData,
});

const Deposits = mongoose.model("deposits", userSchema);

function validateDeposits(deposits) {
  const schema = Joi.object({
    gateway: Joi.string().required(),
  });

  return Joi.validate(deposits, schema);
}

export { Deposits, validateDeposits };
