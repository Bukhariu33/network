import User from "../models/user";
import Joi from "joi";
const R = require("ramda");

const profile = async (req, res) => {
  const schema = Joi.object().keys({
    name: Joi.string().min(3).max(255),
    email: Joi.string().min(5).max(255).email(),
    phone: Joi.string().min(5).max(255),
    address: Joi.string().min(5).max(255),
    state: Joi.string().min(5).max(255),
    zip: Joi.string().min(4).max(255),
    city: Joi.string().min(4).max(255),
    country: Joi.string().min(4).max(255),
  });
  const { error } = Joi.validate(req.body, schema);
  if (error) return res.status(400).send(error.details[0].message);
  try {
    let user_id = req.user._id;
    let info = {
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      address: req.body.address,
      state: req.body.state,
      zip: req.body.zip,
      city: req.body.city,
      country: req.body.country,
    };
    let user = await User.updateOne(
      { _id: user_id },
      { $set: info },
      { upsert: true }
    );
    if (!user) return res.status(400).send("User profile not updated");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
    message: "User Profile is updated",
  });
};

const profile_get = async (req, res) => {
  let user_id = req.user._id;
  try {
    var user = await User.findOne({ _id: user_id });
    if (!user)
      return res.status(404).send("The User with the given name is not found.");
  } catch (err) {
    return res.json({ error: err.message });
  }
  return res.json({
     user,
  });
};

module.exports = {
  profile,
  profile_get,
};
