import Joi from "joi";
import mongoose from "mongoose";
const Schema = mongoose.Schema;
//const objectId = Schema.Types.objectId

// Define our model
const userSchema = new Schema({
  full_name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
  },
  description: {
    type: String,
  },
});

const Users = mongoose.model("user-managements", userSchema);

// Export the model
exports.Users = Users;
// exports.validateCategory = validateCategory;
